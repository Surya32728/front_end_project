import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { AlertCircle, Package, Phone, Calendar } from 'lucide-react';

export default function RecipientDashboard() {
  const { user } = useAuth();
  const { requests, addRequest } = useData();
  const [itemName, setItemName] = useState('');
  const [itemType, setItemType] = useState('');
  const [quantity, setQuantity] = useState('');
  const [contact, setContact] = useState('');
  const [urgency, setUrgency] = useState('');

  const myRequests = requests.filter(r => r.recipientId === user?.id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!itemName || !itemType || !quantity || !contact || !urgency) {
      toast.error('All fields are required');
      return;
    }

    addRequest({
      recipientId: user!.id,
      recipientName: user!.name,
      itemName,
      itemType: itemType as any,
      quantity: parseInt(quantity),
      contact,
      urgency: urgency as any,
      status: 'pending',
    });

    toast.success('Request submitted successfully!');
    setItemName('');
    setItemType('');
    setQuantity('');
    setContact('');
    setUrgency('');
  };

  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/20',
      approved: 'bg-blue-500/10 text-blue-700 border-blue-500/20',
      matched: 'bg-purple-500/10 text-purple-700 border-purple-500/20',
      fulfilled: 'bg-green-500/10 text-green-700 border-green-500/20',
    };
    return colors[status as keyof typeof colors] || '';
  };

  const getUrgencyColor = (urgency: string) => {
    const colors = {
      low: 'bg-blue-500/10 text-blue-700 border-blue-500/20',
      medium: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/20',
      high: 'bg-red-500/10 text-red-700 border-red-500/20',
    };
    return colors[urgency as keyof typeof colors] || '';
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Welcome, {user?.name}!</h1>
        <p className="text-muted-foreground">Request help and track your requests</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Request Form */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle>Request Help</CardTitle>
            <CardDescription>Submit a request for items you need</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="itemName">Item Name</Label>
                <Input
                  id="itemName"
                  placeholder="e.g., Food supplies"
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="itemType">Item Type</Label>
                <Select value={itemType} onValueChange={setItemType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="food">Food</SelectItem>
                    <SelectItem value="clothes">Clothes</SelectItem>
                    <SelectItem value="medicine">Medicine</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  placeholder="e.g., 5"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contact">Contact Number</Label>
                <Input
                  id="contact"
                  placeholder="e.g., +1234567890"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="urgency">Urgency Level</Label>
                <Select value={urgency} onValueChange={setUrgency}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select urgency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" className="w-full">
                Submit Request
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Request Stats */}
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <Card className="shadow-soft">
              <CardContent className="p-6 text-center">
                <AlertCircle className="h-8 w-8 mx-auto mb-2 text-primary" />
                <p className="text-2xl font-bold">{myRequests.length}</p>
                <p className="text-sm text-muted-foreground">Total Requests</p>
              </CardContent>
            </Card>
            <Card className="shadow-soft">
              <CardContent className="p-6 text-center">
                <Package className="h-8 w-8 mx-auto mb-2 text-accent" />
                <p className="text-2xl font-bold">
                  {myRequests.filter(r => r.status === 'fulfilled').length}
                </p>
                <p className="text-sm text-muted-foreground">Fulfilled</p>
              </CardContent>
            </Card>
          </div>

          {myRequests.length === 0 ? (
            <Card className="shadow-soft">
              <CardContent className="p-8 text-center">
                <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">No requests yet. Submit your first request for help!</p>
              </CardContent>
            </Card>
          ) : null}
        </div>
      </div>

      {/* My Requests List */}
      {myRequests.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">My Requests</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {myRequests.map((request) => (
              <Card key={request.id} className="shadow-soft hover:shadow-medium transition-shadow">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-semibold text-lg">{request.itemName}</h3>
                    <Badge className={getStatusColor(request.status)}>
                      {request.status}
                    </Badge>
                  </div>
                  <div className="space-y-2 text-sm mb-3">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Package className="h-4 w-4" />
                      <span>{request.quantity} × {request.itemType}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span>{request.contact}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(request.date).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Badge className={getUrgencyColor(request.urgency)}>
                    {request.urgency} urgency
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
