import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Package, Users, TrendingUp, AlertCircle } from 'lucide-react';

export default function AdminDashboard() {
  const { donations, requests, drives, updateDonationStatus, updateRequestStatus } = useData();

  const handleApproveDonation = (id: string) => {
    updateDonationStatus(id, 'approved');
    toast.success('Donation approved!');
  };

  const handleApproveRequest = (id: string) => {
    updateRequestStatus(id, 'approved');
    toast.success('Request approved!');
  };

  const stats = [
    { label: 'Total Donations', value: donations.length, icon: Package, color: 'text-primary' },
    { label: 'Total Requests', value: requests.length, icon: Users, color: 'text-secondary' },
    { label: 'Active Drives', value: drives.filter(d => d.status === 'active').length, icon: TrendingUp, color: 'text-accent' },
    { label: 'Pending Actions', value: donations.filter(d => d.status === 'pending').length + requests.filter(r => r.status === 'pending').length, icon: AlertCircle, color: 'text-destructive' },
  ];

  const donationsByType = [
    { name: 'Food', value: donations.filter(d => d.itemType === 'food').length },
    { name: 'Clothes', value: donations.filter(d => d.itemType === 'clothes').length },
    { name: 'Medicine', value: donations.filter(d => d.itemType === 'medicine').length },
    { name: 'Other', value: donations.filter(d => d.itemType === 'other').length },
  ];

  const statusData = [
    { name: 'Pending', donations: donations.filter(d => d.status === 'pending').length, requests: requests.filter(r => r.status === 'pending').length },
    { name: 'Approved', donations: donations.filter(d => d.status === 'approved').length, requests: requests.filter(r => r.status === 'approved').length },
    { name: 'In Progress', donations: donations.filter(d => d.status === 'in-transit').length, requests: requests.filter(r => r.status === 'matched').length },
    { name: 'Completed', donations: donations.filter(d => d.status === 'delivered').length, requests: requests.filter(r => r.status === 'fulfilled').length },
  ];

  const COLORS = ['hsl(180, 65%, 45%)', 'hsl(30, 80%, 60%)', 'hsl(150, 60%, 55%)', 'hsl(200, 15%, 60%)'];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage donations, requests, and oversee platform operations</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="shadow-soft">
              <CardContent className="p-6 text-center">
                <Icon className={`h-10 w-10 mx-auto mb-3 ${stat.color}`} />
                <p className="text-3xl font-bold mb-2">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle>Donations & Requests by Status</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={statusData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="donations" fill="hsl(180, 65%, 45%)" name="Donations" />
                <Bar dataKey="requests" fill="hsl(30, 80%, 60%)" name="Requests" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle>Donations by Type</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={donationsByType}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {donationsByType.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Pending Approvals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pending Donations */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle>Pending Donations ({donations.filter(d => d.status === 'pending').length})</CardTitle>
          </CardHeader>
          <CardContent>
            {donations.filter(d => d.status === 'pending').length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No pending donations</p>
            ) : (
              <div className="space-y-4">
                {donations.filter(d => d.status === 'pending').slice(0, 5).map((donation) => (
                  <div key={donation.id} className="border rounded-lg p-4 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">{donation.itemName}</p>
                        <p className="text-sm text-muted-foreground">by {donation.donorName}</p>
                      </div>
                      <Badge>pending</Badge>
                    </div>
                    <p className="text-sm">{donation.quantity} × {donation.itemType}</p>
                    <p className="text-sm text-muted-foreground">{donation.location}</p>
                    <Button onClick={() => handleApproveDonation(donation.id)} size="sm" className="w-full">
                      Approve
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pending Requests */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle>Pending Requests ({requests.filter(r => r.status === 'pending').length})</CardTitle>
          </CardHeader>
          <CardContent>
            {requests.filter(r => r.status === 'pending').length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No pending requests</p>
            ) : (
              <div className="space-y-4">
                {requests.filter(r => r.status === 'pending').slice(0, 5).map((request) => (
                  <div key={request.id} className="border rounded-lg p-4 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">{request.itemName}</p>
                        <p className="text-sm text-muted-foreground">by {request.recipientName}</p>
                      </div>
                      <Badge className={
                        request.urgency === 'high' ? 'bg-red-500/10 text-red-700' :
                        request.urgency === 'medium' ? 'bg-yellow-500/10 text-yellow-700' :
                        'bg-blue-500/10 text-blue-700'
                      }>
                        {request.urgency}
                      </Badge>
                    </div>
                    <p className="text-sm">{request.quantity} × {request.itemType}</p>
                    <p className="text-sm text-muted-foreground">{request.contact}</p>
                    <Button onClick={() => handleApproveRequest(request.id)} size="sm" className="w-full">
                      Approve
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
