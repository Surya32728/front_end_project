import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Calendar, MapPin, TrendingUp, Package } from 'lucide-react';

export default function ActiveDrives() {
  const { drives } = useData();
  const activeDrives = drives.filter(d => d.status === 'active');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Active Donation Drives</h1>
        <p className="text-muted-foreground">Join ongoing drives and help make a difference</p>
      </div>

      {activeDrives.length === 0 ? (
        <Card className="shadow-medium">
          <CardContent className="p-12 text-center">
            <TrendingUp className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-2xl font-semibold mb-2">No Active Drives</h2>
            <p className="text-muted-foreground">Check back later for new donation drives!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeDrives.map((drive) => {
            const progress = (drive.currentAmount / drive.targetAmount) * 100;
            return (
              <Card key={drive.id} className="shadow-soft hover:shadow-medium transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl">{drive.title}</CardTitle>
                    <Badge className="bg-green-500/10 text-green-700">active</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-sm">{drive.description}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-semibold">
                        {drive.currentAmount} / {drive.targetAmount}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{drive.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>
                        {new Date(drive.startDate).toLocaleDateString()} - {new Date(drive.endDate).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Package className="h-4 w-4" />
                      <span>{Math.round(progress)}% Complete</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Sample Message if no drives */}
      {activeDrives.length === 0 && (
        <div className="mt-12 bg-muted/30 rounded-lg p-8 text-center">
          <h3 className="text-xl font-semibold mb-3">Want to create a donation drive?</h3>
          <p className="text-muted-foreground">
            Admins can create and manage donation drives to coordinate community efforts during emergencies.
          </p>
        </div>
      )}
    </div>
  );
}
