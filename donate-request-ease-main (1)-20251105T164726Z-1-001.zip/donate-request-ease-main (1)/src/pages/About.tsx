import { Card, CardContent } from '@/components/ui/card';
import { Heart, Users, Shield, TrendingUp } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Heart,
      title: 'Compassion First',
      description: 'We believe in the power of human kindness and community support during times of need.',
    },
    {
      icon: Users,
      title: 'Community Driven',
      description: 'Built by the community, for the community. Everyone has a role to play in helping others.',
    },
    {
      icon: Shield,
      title: 'Transparent & Secure',
      description: 'Complete transparency in donations and requests. Your trust is our priority.',
    },
    {
      icon: TrendingUp,
      title: 'Impact Focused',
      description: 'Every donation counts. We track and measure the real impact of your contributions.',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold mb-6">About CareConnect</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          We're on a mission to connect donors with those in need during emergencies and natural disasters,
          making help accessible when it matters most.
        </p>
      </div>

      {/* Mission Section */}
      <div className="mb-16">
        <Card className="shadow-medium bg-gradient-card">
          <CardContent className="p-12">
            <h2 className="text-3xl font-bold mb-6 text-center">Our Mission</h2>
            <p className="text-lg text-muted-foreground text-center max-w-4xl mx-auto mb-8">
              CareConnect is a donation management platform that bridges the gap between those who want to help
              and those who need help. During natural disasters and emergencies, we ensure that essential items
              like food, clothes, and medicines reach those who need them most, efficiently and transparently.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <div className="text-center p-6">
                <div className="text-4xl font-bold text-primary mb-2">4</div>
                <p className="text-muted-foreground">User Roles</p>
              </div>
              <div className="text-center p-6">
                <div className="text-4xl font-bold text-primary mb-2">100%</div>
                <p className="text-muted-foreground">Transparent</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Values Section */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8 text-center">Our Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => {
            const Icon = value.icon;
            return (
              <Card key={index} className="shadow-soft hover:shadow-medium transition-shadow text-center">
                <CardContent className="p-8">
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg mb-3">{value.title}</h3>
                  <p className="text-muted-foreground text-sm">{value.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* How It Works */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8 text-center">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="shadow-soft">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold mb-4">For Donors</h3>
              <ol className="space-y-3 text-muted-foreground">
                <li className="flex gap-3">
                  <span className="font-bold text-primary">1.</span>
                  <span>Sign up as a donor and create your profile</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-primary">2.</span>
                  <span>Browse active donation drives or create donations</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-primary">3.</span>
                  <span>Add items you want to donate with details</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-primary">4.</span>
                  <span>Track your donations and see the impact</span>
                </li>
              </ol>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold mb-4">For Recipients</h3>
              <ol className="space-y-3 text-muted-foreground">
                <li className="flex gap-3">
                  <span className="font-bold text-secondary">1.</span>
                  <span>Register as a recipient on the platform</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-secondary">2.</span>
                  <span>Submit requests for items you need</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-secondary">3.</span>
                  <span>Wait for admin approval and matching</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-secondary">4.</span>
                  <span>Track delivery status and receive help</span>
                </li>
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Team Section */}
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-6">Our Team</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
          CareConnect is built by a dedicated team of developers, designers, and community advocates
          passionate about making a difference during emergencies.
        </p>
        <div className="bg-gradient-hero text-white rounded-lg p-8">
          <p className="text-lg font-semibold">
            Together, we can make the world a better place, one donation at a time.
          </p>
        </div>
      </div>
    </div>
  );
}
