import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Package, MapPin, Calendar } from 'lucide-react';

export default function DonorDashboard() {
  const { user } = useAuth();
  const { donations, addDonation } = useData();
  const [itemName, setItemName] = useState('');
  const [itemType, setItemType] = useState('');
  const [quantity, setQuantity] = useState('');
  const [location, setLocation] = useState('');

  const myDonations = donations.filter(d => d.donorId === user?.id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!itemName || !itemType || !quantity || !location) {
      toast.error('All fields are required');
      return;
    }

    addDonation({
      donorId: user!.id,
      donorName: user!.name,
      itemName,
      itemType: itemType as any,
      quantity: parseInt(quantity),
      location,
      status: 'pending',
    });

    toast.success('Donation added successfully!');
    setItemName('');
    setItemType('');
    setQuantity('');
    setLocation('');
  };

  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/20',
      approved: 'bg-blue-500/10 text-blue-700 border-blue-500/20',
      'in-transit': 'bg-purple-500/10 text-purple-700 border-purple-500/20',
      delivered: 'bg-green-500/10 text-green-700 border-green-500/20',
    };
    return colors[status as keyof typeof colors] || '';
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Welcome, {user?.name}!</h1>
        <p className="text-muted-foreground">Manage your donations and track their impact</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Donation Form */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle>Create New Donation</CardTitle>
            <CardDescription>Fill in the details to donate items</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="itemName">Item Name</Label>
                <Input
                  id="itemName"
                  placeholder="e.g., Rice bags"
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="itemType">Item Type</Label>
                <Select value={itemType} onValueChange={setItemType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="food">Food</SelectItem>
                    <SelectItem value="clothes">Clothes</SelectItem>
                    <SelectItem value="medicine">Medicine</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  placeholder="e.g., 10"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Pickup Location</Label>
                <Input
                  id="location"
                  placeholder="e.g., New York, NY"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>

              <Button type="submit" className="w-full">
                Add Donation
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Donation Stats */}
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <Card className="shadow-soft">
              <CardContent className="p-6 text-center">
                <Package className="h-8 w-8 mx-auto mb-2 text-primary" />
                <p className="text-2xl font-bold">{myDonations.length}</p>
                <p className="text-sm text-muted-foreground">Total Donations</p>
              </CardContent>
            </Card>
            <Card className="shadow-soft">
              <CardContent className="p-6 text-center">
                <Package className="h-8 w-8 mx-auto mb-2 text-accent" />
                <p className="text-2xl font-bold">
                  {myDonations.filter(d => d.status === 'delivered').length}
                </p>
                <p className="text-sm text-muted-foreground">Delivered</p>
              </CardContent>
            </Card>
          </div>

          {myDonations.length === 0 ? (
            <Card className="shadow-soft">
              <CardContent className="p-8 text-center">
                <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">No donations yet. Start by creating your first donation!</p>
              </CardContent>
            </Card>
          ) : null}
        </div>
      </div>

      {/* My Donations List */}
      {myDonations.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">My Donations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {myDonations.map((donation) => (
              <Card key={donation.id} className="shadow-soft hover:shadow-medium transition-shadow">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-semibold text-lg">{donation.itemName}</h3>
                    <Badge className={getStatusColor(donation.status)}>
                      {donation.status}
                    </Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Package className="h-4 w-4" />
                      <span>{donation.quantity} × {donation.itemType}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{donation.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(donation.date).toLocaleDateString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
