import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Truck, Package, MapPin, Calendar } from 'lucide-react';

export default function LogisticsDashboard() {
  const { donations, updateDonationStatus } = useData();

  const handleStartTransit = (id: string) => {
    updateDonationStatus(id, 'in-transit');
    toast.success('Delivery started!');
  };

  const handleComplete = (id: string) => {
    updateDonationStatus(id, 'delivered');
    toast.success('Delivery completed!');
  };

  const approvedDonations = donations.filter(d => d.status === 'approved');
  const inTransitDonations = donations.filter(d => d.status === 'in-transit');
  const deliveredDonations = donations.filter(d => d.status === 'delivered');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Logistics Dashboard</h1>
        <p className="text-muted-foreground">Manage transportation and delivery of donations</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <Package className="h-10 w-10 mx-auto mb-3 text-primary" />
            <p className="text-3xl font-bold mb-2">{approvedDonations.length}</p>
            <p className="text-sm text-muted-foreground">Ready for Pickup</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <Truck className="h-10 w-10 mx-auto mb-3 text-secondary" />
            <p className="text-3xl font-bold mb-2">{inTransitDonations.length}</p>
            <p className="text-sm text-muted-foreground">In Transit</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <Package className="h-10 w-10 mx-auto mb-3 text-accent" />
            <p className="text-3xl font-bold mb-2">{deliveredDonations.length}</p>
            <p className="text-sm text-muted-foreground">Delivered</p>
          </CardContent>
        </Card>
      </div>

      {/* Ready for Pickup */}
      <Card className="shadow-medium mb-8">
        <CardHeader>
          <CardTitle>Ready for Pickup ({approvedDonations.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {approvedDonations.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No donations ready for pickup</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {approvedDonations.map((donation) => (
                <div key={donation.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold">{donation.itemName}</h3>
                    <Badge className="bg-blue-500/10 text-blue-700">approved</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Package className="h-4 w-4" />
                      <span>{donation.quantity} × {donation.itemType}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{donation.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(donation.date).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Button onClick={() => handleStartTransit(donation.id)} size="sm" className="w-full">
                    <Truck className="h-4 w-4 mr-2" />
                    Start Delivery
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* In Transit */}
      <Card className="shadow-medium">
        <CardHeader>
          <CardTitle>In Transit ({inTransitDonations.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {inTransitDonations.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No donations in transit</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {inTransitDonations.map((donation) => (
                <div key={donation.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold">{donation.itemName}</h3>
                    <Badge className="bg-purple-500/10 text-purple-700">in-transit</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Package className="h-4 w-4" />
                      <span>{donation.quantity} × {donation.itemType}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{donation.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(donation.date).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Button onClick={() => handleComplete(donation.id)} size="sm" className="w-full" variant="secondary">
                    Mark as Delivered
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
