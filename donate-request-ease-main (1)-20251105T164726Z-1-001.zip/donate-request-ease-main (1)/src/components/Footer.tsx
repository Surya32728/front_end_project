import { Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-card border-t mt-20">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Heart className="h-5 w-5 fill-primary text-primary" />
              <span className="font-bold text-lg">CareConnect</span>
            </div>
            <p className="text-muted-foreground text-sm">
              Connecting donors with those in need during emergencies and natural disasters.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <div className="flex flex-col gap-2">
              <Link to="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                About Us
              </Link>
              <Link to="/drives" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Active Drives
              </Link>
              <Link to="/contact" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Get Started</h3>
            <div className="flex flex-col gap-2">
              <Link to="/signup" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Become a Donor
              </Link>
              <Link to="/signup" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Request Help
              </Link>
              <Link to="/signin" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Sign In
              </Link>
            </div>
          </div>
        </div>
        
        <div className="border-t mt-8 pt-6 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} CareConnect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
