import { createContext, useContext, ReactNode } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Donation, Request, Drive } from '@/types';

interface DataContextType {
  donations: Donation[];
  addDonation: (donation: Omit<Donation, 'id' | 'date'>) => void;
  updateDonationStatus: (id: string, status: Donation['status']) => void;
  requests: Request[];
  addRequest: (request: Omit<Request, 'id' | 'date'>) => void;
  updateRequestStatus: (id: string, status: Request['status']) => void;
  drives: Drive[];
  addDrive: (drive: Omit<Drive, 'id' | 'currentAmount'>) => void;
  updateDrive: (id: string, updates: Partial<Drive>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [donations, setDonations] = useLocalStorage<Donation[]>('careconnect_donations', []);
  const [requests, setRequests] = useLocalStorage<Request[]>('careconnect_requests', []);
  const [drives, setDrives] = useLocalStorage<Drive[]>('careconnect_drives', []);

  const addDonation = (donation: Omit<Donation, 'id' | 'date'>) => {
    const newDonation: Donation = {
      ...donation,
      id: `donation_${Date.now()}`,
      date: new Date().toISOString(),
      status: 'pending',
    };
    setDonations([...donations, newDonation]);
  };

  const updateDonationStatus = (id: string, status: Donation['status']) => {
    setDonations(donations.map(d => d.id === id ? { ...d, status } : d));
  };

  const addRequest = (request: Omit<Request, 'id' | 'date'>) => {
    const newRequest: Request = {
      ...request,
      id: `request_${Date.now()}`,
      date: new Date().toISOString(),
      status: 'pending',
    };
    setRequests([...requests, newRequest]);
  };

  const updateRequestStatus = (id: string, status: Request['status']) => {
    setRequests(requests.map(r => r.id === id ? { ...r, status } : r));
  };

  const addDrive = (drive: Omit<Drive, 'id' | 'currentAmount'>) => {
    const newDrive: Drive = {
      ...drive,
      id: `drive_${Date.now()}`,
      currentAmount: 0,
    };
    setDrives([...drives, newDrive]);
  };

  const updateDrive = (id: string, updates: Partial<Drive>) => {
    setDrives(drives.map(d => d.id === id ? { ...d, ...updates } : d));
  };

  return (
    <DataContext.Provider value={{
      donations,
      addDonation,
      updateDonationStatus,
      requests,
      addRequest,
      updateRequestStatus,
      drives,
      addDrive,
      updateDrive,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
