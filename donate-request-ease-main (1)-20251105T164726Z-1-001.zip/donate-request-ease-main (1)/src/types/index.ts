export type UserRole = 'donor' | 'recipient' | 'admin' | 'coordinator';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
}

export interface Donation {
  id: string;
  donorId: string;
  donorName: string;
  itemName: string;
  itemType: 'food' | 'clothes' | 'medicine' | 'other';
  quantity: number;
  location: string;
  status: 'pending' | 'approved' | 'in-transit' | 'delivered';
  date: string;
}

export interface Request {
  id: string;
  recipientId: string;
  recipientName: string;
  itemName: string;
  itemType: 'food' | 'clothes' | 'medicine' | 'other';
  quantity: number;
  contact: string;
  urgency: 'low' | 'medium' | 'high';
  status: 'pending' | 'approved' | 'matched' | 'fulfilled';
  date: string;
}

export interface Drive {
  id: string;
  title: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  location: string;
  status: 'active' | 'completed' | 'cancelled';
  startDate: string;
  endDate: string;
}
